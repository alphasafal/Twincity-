# GitHub and live links

- Primary proof: GitHub repository + release tag `hackathon-final-v1`
- Temporary Cloudflare demo URLs are optional and may expire
- Authoritative metrics: Path A comfort-zero EnergyPlus experiment
- Hybrid Path C proves LLM supervisory involvement in the closed loop
