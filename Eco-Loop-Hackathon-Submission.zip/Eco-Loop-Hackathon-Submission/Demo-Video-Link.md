# Demo video

Replace this file with the permanent hosted link before submission.

Required narrative (≤3 minutes):
EnergyPlus observation → MCP tools/call → Ollama strategy → deterministic optimiser →
SafetyShield → Clg-SetP-Sch → next EnergyPlus state → results (4.98% HVAC, 0 comfort violations).
